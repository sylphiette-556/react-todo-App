import { background, extendTheme } from "@chakra-ui/react";

export const theme = extendTheme({
    styles: {
        global: {
            body: {
                background: "#f0f0f0",
            }
        }
    }
})