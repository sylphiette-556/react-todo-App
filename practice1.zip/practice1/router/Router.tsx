import { FC, memo } from "react";
import { Route, Routes } from "react-router-dom";
import { HomePage } from "../components/pages/HomePage";
import { LoginPage } from "../components/pages/LoginPage";
import { NotFoundPage } from "../components/pages/NotFoundPage";
import { Header } from "../components/organisms/Header";

export const Router: FC = memo(() => {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </>
  );
});
