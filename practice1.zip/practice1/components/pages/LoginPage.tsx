import { Button, Card, CardBody, Divider, Flex, Heading, Input, Stack } from "@chakra-ui/react";
import { FC, memo } from "react";
import { useNavigate } from "react-router-dom";

export const LoginPage: FC = memo(() => {

  const navigate = useNavigate();

  const onClickLogin = () => {
    navigate("/");
  }

  return (
    <Flex height="100vh" justify="center" align="center">
        <Card width="30%">
          <CardBody>
            <Heading as="h1" textAlign="center" pb={2}>ログイン</Heading>
            <Divider color=""/>
            <Stack spacing={5}>
            <Input placeholder="ユーザID" />
           <Button colorScheme="teal" onClick={onClickLogin}>ログイン</Button>
            </Stack>
          </CardBody>
        </Card>
    </Flex>
  );
});
