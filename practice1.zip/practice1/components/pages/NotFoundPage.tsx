import { Link } from "@chakra-ui/react";
import { FC, memo } from "react";
import { useNavigate } from "react-router-dom";

export const NotFoundPage: FC = memo(() => {

    const navigate = useNavigate();

    const onClickHome = () => {
        navigate("/");
    }
  return (
    <>
      <h1>Page NotFound</h1>
      <Link onClick={onClickHome}>ホームに戻る</Link>
    </>
  );
});
