import {
  Box,
  Flex,
  Textarea,
} from "@chakra-ui/react";
import { FC, memo, useState } from "react";
import { Card } from "../molucules/Card";

export const HomePage: FC = memo(() => {
  const [text, setText] = useState("");
  const [rows, setRows] = useState(1);
  const [messageList, setMessageList] = useState<Array<string>>([]);

  const onChangetext = (e: any) => {
    e.target.style.height = "auto";
    e.target.style.height = e.target.scrollHeight + "px";
    setText(e.target.value);
  };

  const onKeyJudge = (e: any) => {
    // Cmd + Enter もしくは Ctrl + Enter
  if ((e.key === "Enter" && (e.ctrlKey || e.metaKey)) && text !== '') {
    enterSubmit(e);
  }
  };
  const enterSubmit = (e: any) => {
    e.preventDefault();
    setMessageList([...messageList, text])
    setText('');
  };
  return (
    <>
      {/**サイドナビ */}
      <Flex
        position="fixed"
        direction="column"
        left="0"
        h="100vh"
        w="240px"
        bg="blue.400"
      >
        <p>a</p>
        <p>b</p>
        <p>c</p>
      </Flex>
      {/** チャット欄 */}
      <Flex direction="column" h="100vh" pl="240px">
        <Card cardList={messageList}/>
        {/** メッセージ入力欄 */}
        <Flex
          position="fixed"
          bottom={0}
          width="full"
          direction="column"
          //   height="150px"
        >
          {/* <Flex w="68%"> */}
            <form onSubmit={enterSubmit}>
          <Box>
              <Textarea
                onChange={onChangetext}
                onKeyDown={onKeyJudge}
                rows={rows}
                placeholder="メッセージを入力"
                bg="#fff"
                borderWidth={2}
                borderColor="blackAlpha.800"
                value={text}
              />
          </Box>
            </form>
          {/* </Flex> */}
        </Flex>
      </Flex>
    </>
  );
});
