import { Box, Flex, Heading, Link } from "@chakra-ui/react";
import { FC, memo } from "react";
import { useNavigate } from "react-router-dom";

export const Header: FC = memo(() => {
  const navigate = useNavigate();

  const onClickLogout = () => {
    navigate("/login");
  };

  return (
    // <Box as="header" >
    // <Flex bg="teal.300" >
    // <Heading  h="60px">My App</Heading>
    // <Link>ss</Link>

    // </Flex>
    // </Box>
    /** heightとptの値を一致させる */
    <Box pt="60px">
      <Flex
        as="header"
        position="fixed"
        bg="teal.300"
        top={0}
        width="full"
        height="60px"
        shadow="sm"
      >
        <Heading m="3px 0 0 5px" _hover={{ cursor: "pointer" }}>
          MyApp
        </Heading>
        <Link
          fontSize="20px"
          fontWeight="bold"
          m="auto 10px"
          ml="auto"
          _hover={{ cursor: "pointer" }}
          onClick={onClickLogout}
        >
          ログアウト
        </Link>
      </Flex>
    </Box>
  );
});
