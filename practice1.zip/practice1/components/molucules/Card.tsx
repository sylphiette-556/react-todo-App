import { Flex } from "@chakra-ui/react";
import { FC, memo } from "react";

type Props = {
  cardList: any;
};
export const Card: FC<Props> = memo((props) => {
  const { cardList } = props;
  return (
    <>
      {cardList.map((card: string) => {
        return ( 
          <Flex whiteSpace="pre-wrap" m={1} w="90%" opacity="0.8" transition="height 200ms,background-color 200ms" _hover={{cursor: "pointer", backgroundColor: "#fff"}} key={card}>
            <h1>㋑ : </h1>
            <h1 >{card}</h1>
          </Flex>
        );
      })}
    </>
  );
});
